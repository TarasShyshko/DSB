<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* themes/custom/exam/templates/flag.html.twig */
class __TwigTemplate_f80ff14c13ef839ebf98ab4099a3d40a extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
        $this->sandbox = $this->env->getExtension('\Twig\Extension\SandboxExtension');
        $this->checkSecurity();
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 17
        ob_start(function () { return ''; });
        // line 18
        echo "  ";
        // line 19
        echo "  ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\Core\Template\TwigExtension']->attachLibrary("flag/flag.link"), "html", null, true);
        echo "

  ";
        // line 22
        echo "  ";
        if ((($context["action"] ?? null) == "unflag")) {
            // line 23
            echo "    ";
            $context["action_class"] = "action-unflag";
            // line 24
            echo "    ";
            $context["icon_class"] = "fa-thumbs-up";
            echo " ";
            // line 25
            echo "  ";
        } else {
            // line 26
            echo "    ";
            $context["action_class"] = "action-flag";
            // line 27
            echo "    ";
            $context["icon_class"] = "fa-heart";
            echo " ";
            // line 28
            echo "  ";
        }
        // line 29
        echo "
  ";
        // line 31
        echo "  ";
        // line 32
        $context["classes"] = [0 => "flag", 1 => ("flag-" . \Drupal\Component\Utility\Html::getClass($this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source,         // line 34
($context["flag"] ?? null), "id", [], "method", false, false, true, 34), 34, $this->source))), 2 => ((("js-flag-" . \Drupal\Component\Utility\Html::getClass($this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source,         // line 35
($context["flag"] ?? null), "id", [], "method", false, false, true, 35), 35, $this->source))) . "-") . $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, ($context["flaggable"] ?? null), "id", [], "method", false, false, true, 35), 35, $this->source)), 3 =>         // line 36
($context["action_class"] ?? null)];
        // line 39
        echo "
  ";
        // line 41
        echo "  ";
        $context["attributes"] = twig_get_attribute($this->env, $this->source, ($context["attributes"] ?? null), "setAttribute", [0 => "rel", 1 => "nofollow"], "method", false, false, true, 41);
        // line 42
        echo "
  <div class=\"";
        // line 43
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, twig_join_filter($this->sandbox->ensureToStringAllowed(($context["classes"] ?? null), 43, $this->source), " "), "html", null, true);
        echo "\">
    <a";
        // line 44
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["attributes"] ?? null), 44, $this->source), "html", null, true);
        echo ">
      <i class=\"fa-regular ";
        // line 45
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["icon_class"] ?? null), 45, $this->source), "html", null, true);
        echo " fa-sm\" style=\"color: #a6a6a6;\"></i>
    </a>
  </div>
";
        $___internal_parse_1_ = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        // line 17
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(twig_spaceless($___internal_parse_1_));
        // line 49
        echo "

";
    }

    public function getTemplateName()
    {
        return "themes/custom/exam/templates/flag.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  108 => 49,  106 => 17,  99 => 45,  95 => 44,  91 => 43,  88 => 42,  85 => 41,  82 => 39,  80 => 36,  79 => 35,  78 => 34,  77 => 32,  75 => 31,  72 => 29,  69 => 28,  65 => 27,  62 => 26,  59 => 25,  55 => 24,  52 => 23,  49 => 22,  43 => 19,  41 => 18,  39 => 17,);
    }

    public function getSourceContext()
    {
        return new Source("", "themes/custom/exam/templates/flag.html.twig", "/var/www/web/themes/custom/exam/templates/flag.html.twig");
    }
    
    public function checkSecurity()
    {
        static $tags = array("apply" => 17, "if" => 22, "set" => 23);
        static $filters = array("escape" => 19, "clean_class" => 34, "join" => 43, "spaceless" => 17);
        static $functions = array("attach_library" => 19);

        try {
            $this->sandbox->checkSecurity(
                ['apply', 'if', 'set'],
                ['escape', 'clean_class', 'join', 'spaceless'],
                ['attach_library']
            );
        } catch (SecurityError $e) {
            $e->setSourceContext($this->source);

            if ($e instanceof SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

    }
}
